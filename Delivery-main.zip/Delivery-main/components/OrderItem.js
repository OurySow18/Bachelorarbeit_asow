import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const OrderItem = () => {
  return (
    <View>
      <Text>OrderItem</Text>
    </View>
  )
}

export default OrderItem

const styles = StyleSheet.create({})