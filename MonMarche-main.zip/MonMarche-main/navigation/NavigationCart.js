import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import CustomHeaderIcon from '../components/products/CustomHeaderIcon';

import Cart from '../screens/products/Cart';
import LieferungsInfos from '../screens/products/LieferungsInfos';
import globalStyles from '../assets/consts/globalStyles';
import COLORS from '../assets/consts/colors';
import PaymentProzess from '../screens/products/PaymentProzess';

const CartStack = createStackNavigator();

export const CartNavigator = () => {
  return (
    <CartStack.Navigator  screenOptions={({ navigation }) => ({  
                      headerShown: true,
                      headerStyle: {backgroundColor: COLORS.accentColor},
                      headerTitleStyle: { fontWeight: 'bold'},
                      headerTintColor: globalStyles.white,
                      headerRight: () => (
                        <HeaderButtons HeaderButtonComponent={CustomHeaderIcon}>
                           <Item 
                            title="Panier"
                            iconName="shopping-cart"
                            onPress={() => navigation.navigate('CartProd')}
                            />
                            
                        </HeaderButtons>
                    ),
                    headerLeft: () => (
                      <HeaderButtons HeaderButtonComponent={CustomHeaderIcon}>
                         <Item 
                          title="Menu"
                          iconName="menu"
                          onPress={() => navigation.openDrawer()}
                          />
                          
                      </HeaderButtons>
                  )
                      })} >
          <CartStack.Screen 
                  name="Cart" 
                  component={Cart}
                  options={{title: 'Panier'}}
                  />
          <CartStack.Screen 
                  name="Delivery" 
                  component={LieferungsInfos}
                  options={{title: 'Delivery Infos'}}
                  />
          <CartStack.Screen 
                  name="PaymentProzess" 
                  component={PaymentProzess}
                  options={{title: 'Payment Prozess'}}
                  />
   
  </CartStack.Navigator>
  )
}

