/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Diese Navigator ist für dir die Produkte erstellt. 
 * Wie haben zugriff auf alle Produckt Seite.
 * Die Landing Page, die AllProducts, die ProductInfos und auch die CardProd sind hier aufgerufen
 */
import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';

import Landing from '../screens/Landing';
import ProductInfos from '../screens/products/ProductInfos';
import CustomHeaderIcon from '../components/products/CustomHeaderIcon';

import globalStyles from '../assets/consts/globalStyles';
import COLORS from '../assets/consts/colors';
import AllProducts from '../screens/products/AllProducts';

const ProductStakeNavigator = createStackNavigator();

export const ProductsNavigator = () => {
  return (
    <ProductStakeNavigator.Navigator  screenOptions={({ navigation }) => ({  
                      headerShown: true,
                      headerStyle: {backgroundColor: COLORS.accentColor},
                      headerTitleStyle: { fontWeight: 'bold'},
                      headerTintColor: globalStyles.white,
                      headerRight: () => (
                        <HeaderButtons HeaderButtonComponent={CustomHeaderIcon}>
                           <Item 
                            title="Panier"
                            iconName="shopping-cart"
                            onPress={() => navigation.navigate('CartProd')}
                            korbStatus={true}
                            />
                            
                        </HeaderButtons>
                    ),
                      headerLeft: () => (
                        <HeaderButtons HeaderButtonComponent={CustomHeaderIcon}>
                           <Item 
                            title="Menu"
                            iconName="menu"
                            onPress={() => navigation.openDrawer()}
                            korbStatus={false}
                            />
                            
                        </HeaderButtons>
                    )
                      })} >
                    <ProductStakeNavigator.Screen name="Landing" component={Landing}
                                                  options={{
                                                    title:"Catalogue"
                                                  }}/>
                    <ProductStakeNavigator.Screen name="ProductInfos" component={ProductInfos}
                                                  options={({ route }) => (
                                                    {
                                                      id: route.params.id,
                                                      title: route.params.title
                                                    }
                        )} /> 
                    <ProductStakeNavigator.Screen name="AllProducts" component={AllProducts}
                                                  options={{
                                                    title:"Tous nos Produits"
                                                  }}
                                                    
                         /> 
  </ProductStakeNavigator.Navigator>
  )
}
