import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import CustomHeaderIcon from '../components/products/CustomHeaderIcon';

import Payments from '../screens/products/Payments';

import globalStyles from '../assets/consts/globalStyles';
import COLORS from '../assets/consts/colors';

const PaymentStack = createStackNavigator();

export const PaymentNavigator = () => {
  return (
    <PaymentStack.Navigator  screenOptions={({ navigation }) => ({  
                      headerShown: true,
                      headerStyle: {backgroundColor: COLORS.accentColor},
                      headerTitleStyle: { fontWeight: 'bold'},
                      headerTintColor: globalStyles.white,
                      headerRight: () => (
                        <HeaderButtons HeaderButtonComponent={CustomHeaderIcon}>
                           <Item 
                            title="Panier"
                            iconName="shopping-cart"
                            onPress={() => navigation.navigate('CartProd')}
                            />
                            
                        </HeaderButtons>
                    ),
                    headerLeft: () => (
                      <HeaderButtons HeaderButtonComponent={CustomHeaderIcon}>
                         <Item 
                          title="Menu"
                          iconName="menu"
                          onPress={() => navigation.openDrawer()}
                          />
                          
                      </HeaderButtons>
                  )
                      })} >
                        <PaymentStack.Screen 
                                name="Payment" 
                                component={Payments}
                                options={{title: 'Mes achats'}}
                                />
   
  </PaymentStack.Navigator>
  )
}
