import React from "react";
import { createDrawerNavigator } from '@react-navigation/drawer';
 
import {CartNavigator} from "./NavigationCart";
import {PaymentNavigator} from "./NavigationPayment"; 
import AppNav from "./AppNav";
import CustomDrawerContent from "../components/CustomDrawerContent";
import Help from "../screens/help/Help";
import Settings from "../screens/help/Settings";

const Drawer = createDrawerNavigator();

export const DrawerNavigator = () => {
    return(        
        <Drawer.Navigator
            screenOptions={{
                headerShown: false,
                swipeEdgeWidth: 250
            }}
            drawerContent={ props => <CustomDrawerContent {...props} /> }
        >
            <Drawer.Screen 
                name="Home"
                component={AppNav}
                
            />
            <Drawer.Screen 
                name="CartProd"
                component={CartNavigator}
                
            />
            <Drawer.Screen 
                name="PaymentProd"
                component={PaymentNavigator}
               
            />
            <Drawer.Screen 
                name="Help"
                component={Help}
               
            />
            <Drawer.Screen 
                name="Settings"
                component={Settings}
               
            />
        </Drawer.Navigator>
    )
}