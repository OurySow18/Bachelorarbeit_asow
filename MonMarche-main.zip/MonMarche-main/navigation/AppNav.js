/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Die AppNav ist die BottomTabNavigator, d.h. sie ist unten auf der Bildschirm zu sehen.
 * Sie hat zugriff auf der ProductsNavigator, AllProduct, NavigationUser und der Help screen 
 */
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Help from '../screens/help/Help';

import AntDesign from "react-native-vector-icons/AntDesign";
import Octicons from "react-native-vector-icons/Octicons";
import { MaterialIcons } from '@expo/vector-icons';

import NavigationUser from './NavigationUser';
import {ProductsNavigator} from './NavigationProducts';
import AllProducts from '../screens/products/AllProducts';
import globalStyles from '../assets/consts/globalStyles';

const Tab = createBottomTabNavigator();
const AppNav = () => {
    return (
        <Tab.Navigator
          screenOptions={{            
            headerShown: false,             
            tabBarStyle: { backgroundColor: '#ff6f00' },
            headerTintColor: globalStyles.white,
            tabBarActiveTintColor: '#fff',
            tabBarInactiveTintColor: 'black',
            tabBarInactiveBackgroundColor: '#ff4f00'
          }}
        >
          <Tab.Screen
            name="Products"
            component={ProductsNavigator}
            options={{
              title: 'Monmarche',
              tabBarLabel: 'Acceuil',
              tabBarIcon: ({focused, color, size }) => (
                <AntDesign name="home" size={focused ? 40:24} color="black" />
              )
            }}
          />
          <Tab.Screen
            name="Nos produits"
            component={AllProducts}
            options={{      
              headerShown: true, 
              headerStyle: {backgroundColor: '#ff6f00'},
              title: 'Nos produits',
              tabBarLabel: 'Nos produits',
              tabBarIcon: ({focused, color, size }) => (
                <Octicons name="three-bars" size={focused ? 30:20} color="black" />
              )
            }}
          />
          <Tab.Screen
            name="User"
            component={NavigationUser}
            options={{
              title: 'Connection',
              tabBarLabel: 'User',
              tabBarIcon: ({focused, color, size }) => (
                <AntDesign name="user" size={focused ? 40:24} color="black" />
              )
            }}
          />
          <Tab.Screen
            name="Aide"
            component={Help}
            options={{
              title: 'La page d´aide',
              tabBarLabel: 'Help',
              tabBarIcon: ({focused, color, size }) => (
                <MaterialIcons name="help-outline" size={focused ? 40:24} color={"black"} />
              )
            }}
          />
    
    
        </Tab.Navigator>
    
      );
}

export default AppNav