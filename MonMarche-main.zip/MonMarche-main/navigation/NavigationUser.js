import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import SignInScreen from '../screens/authentification/SignInScreen';
import SignUpScreen from '../screens/authentification/SignUpScreen';
import ConfirmEmailScreen from '../screens/authentification/ConfirmEmailScreen';
import ForgotPasswordScreen from '../screens/authentification/ForgotPasswordScreen';
import NewPasswordScreen from '../screens/authentification/NewPasswordScreen'; 
import ProfilInfos from '../screens/authentification/ProfilInfos';
import UserDetails from '../screens/authentification/UserDetails';

const Stack = createNativeStackNavigator();

const NavigationUser = () => {
  return ( 
      <Stack.Navigator screenOptions={{headerShown: false}}>
        <Stack.Screen name="SignIn" component={SignInScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} />
        <Stack.Screen name="ConfirmEmail" component={ConfirmEmailScreen} />
        <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
        <Stack.Screen name="NewPassword" component={NewPasswordScreen} /> 
        <Stack.Screen name="ProfilInfos" component={ProfilInfos} /> 
        <Stack.Screen name="UserDetails" component={UserDetails} /> 
      </Stack.Navigator>
    
  );
};

export default NavigationUser;
