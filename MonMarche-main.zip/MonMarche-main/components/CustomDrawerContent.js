/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Unser DrawerNavigator wird hier bearbeitet.
 * Der StyleSheet und die Navigetion zu den verschieden Komponenten
 */
import { StyleSheet, View } from "react-native";
import React, {useLayoutEffect, useState} from "react";
import { DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";
import { Avatar, Caption, Drawer, Title } from "react-native-paper";
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from "@react-native-async-storage/async-storage";
import {useNavigation} from '@react-navigation/native';


const CustomDrawerContent = (props) => {  
  
  const navigation = useNavigation();
  const [id, setId] = useState('');
  const [isAuth, setIsAuth] = useState(false)
  
  const disconnect = async() =>{
    try {
      await AsyncStorage.removeItem("userDetails");
      await AsyncStorage.setItem('userSaved', "false")
      console.log("You are disconnected")
    //  navigation.navigate('SignIn');
    } catch (error) {
      alert (error)
    }
  } 
  
  useLayoutEffect(() => {
    load();
  }, [])

  const load = async () => {
    const userDetaisStr = await AsyncStorage.getItem('userDetails');
    
    if (userDetaisStr !== null){
      const userDetailsObj = JSON.parse(userDetaisStr);
      const {token, userId, dateTokenExpire} = userDetailsObj;
      const expireDate = new Date(dateTokenExpire);        
      if (expireDate <= new Date() || !token || !userId){
        setId(userDetailsObj.useId)
        setIsAuth(true);        
        return;
      }
      navigation.navigate('ProfilInfos');
      setIsAuth(true);
    } else {
      setIsAuth(true);
      setId('')
    }
    
  }

  return (
    <View style={styles.container}>
      <DrawerContentScrollView {...props}>
        <View style={styles.drawerContentContainer}>
          <View style={styles.userInfoContainer}>
            <View style={styles.userInfoDetail}>
              <Avatar.Image
                source={{
                  uri: "https://firebasestorage.googleapis.com/v0/b/monmarhe.appspot.com/o/1649763481082Bild_Sow.jpeg?alt=media&token=0adacc52-e4ff-43ed-9c4a-39adfced935f.jpeg",
                }}
                size={90}
              />
            </View>
            <View style={styles.name}>
              <Title style={styles.title}>Amadou Oury Sow</Title>
              <Title style={styles.title}>{id}</Title>
              <Caption style={styles.caption}>amadourys15@yahoo.com</Caption>
            </View>
          </View>
          <Drawer.Section title="Infos" style={styles.drawerSection}>
                <DrawerItem 
                    label="Catalogue"
                    icon={({color, size}) => <MaterialIcons name="menu-book" size={24} color="black" />}
                    onPress={ () =>{props.navigation.navigate('Home')}}
                />
                <DrawerItem 
                    label="Panier"
                    icon={({color, size}) => <MaterialIcons name="shopping-cart" size={24} color="black" />}
                    onPress={ () =>{props.navigation.navigate('CartProd')}}
                />
                <DrawerItem 
                    label="PaymentProd"
                    icon={({color, size}) => <MaterialIcons name="credit-card" size={24} color="black" />}
                    onPress={ () =>{props.navigation.navigate('PaymentProd')}}
                />
                <DrawerItem 
                    label="Help"
                    icon={({color, size}) => <MaterialIcons name="help-outline" size={24} color="black" />}
                    onPress={ () =>{props.navigation.navigate('Help')}}
                />
          </Drawer.Section>
          <Drawer.Section title="Reglages">
          <DrawerItem 
                    label="Parametre de confidentialite"
                    icon={({color, size}) => <MaterialIcons name="settings" size={24} color="black" />}
                    onPress={ () =>{props.navigation.navigate('Settings')}}
                />
          </Drawer.Section>
        </View>
      </DrawerContentScrollView>
      <Drawer.Section style={styles.logout}>
            <Drawer.Item 
                 label="Deconnexion"
                 icon={({color, size}) => <MaterialIcons name="logout" size={24} color="black" />}
                 onPress={disconnect}
            />  
            
      </Drawer.Section>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  drawerContentContainer: {
    flex: 1,
  },
  userInfoContainer: {
    paddingLeft: 20,
  },
  userInfoDetail: {
    marginTop: 15,
  },
  name: {
    marginTop: 15,
    justifyContent: "center",
  },
  title: {
    fontSize: 19,
    marginTop: 5,
    fontWeight: "bold",
  },
  caption: {
    fontSize: 15,
  },
  drawerSection:{
    marginTop: 19,
    borderTopWidth: 1,
    borderTopColor: '#ccc'
  },
  logout:{
    marginBottom:19,
    borderTopWidth: 0.8,
    borderTopColor:'#ccc'
  }
});

export default CustomDrawerContent;
