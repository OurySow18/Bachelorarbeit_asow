import React from 'react'
import { Text, StyleSheet, View } from 'react-native'
import { HeaderButton } from 'react-navigation-header-buttons'
import {MaterialIcons}  from '@expo/vector-icons'
import globalStyles from '../../assets/consts/globalStyles'

const CustomHeaderIcon = (props) => {
  return (
   <View>
    <HeaderButton
        {...props}
        IconComponent={MaterialIcons}
        iconSize={24}
        color={globalStyles.white}
   />
   { props.korbStatus && <Text style={styles.korb}> 2 </Text>}
   </View> 
  )
}

const styles = StyleSheet.create({ 
  korb: {
    width: 15,
    height: 15,
    backgroundColor: "red",
    borderRadius: 15,
    color: "white",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 12,
    fontWeight: "bold",
    position: "absolute",
    top: -6,
    right: 10,
  },
})

export default CustomHeaderIcon