import { StyleSheet, Text, View, TouchableOpacity } from 'react-native'
import React from 'react'
import globalStyles from '../../assets/consts/globalStyles'
import { MaterialIcons } from '@expo/vector-icons';

const ProductsInCart = (props) => {
  return (
    <View style={styles.productContainer}>
      <Text numberOfLines={1} style={styles.productTitle}>{props.name} </Text> 
      <Text  style={styles.productPrice}>{Number(props.price).toFixed(2)} $</Text>
      <TouchableOpacity
        onPress={props.onDelete}
      >
        <MaterialIcons name="delete" size={24} color={globalStyles.green} />
      </TouchableOpacity>
    </View>
  )
}


const styles = StyleSheet.create({

    productContainer:{
        backgroundColor: globalStyles.white,
        borderRadius: 10,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 10,
        marginBottom: 9
    },
    productTitle:{
        width: '60%'
    },
    productPrice: {
        textAlign: 'right',
        paddingRight: 9,
        width: '30%'
    }
})

export default ProductsInCart