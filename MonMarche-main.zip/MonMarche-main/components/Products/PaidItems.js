import { StyleSheet, Text, View, TouchableOpacity } from 'react-native'
import React, {useState} from 'react'
import { ScrollView } from 'react-native-gesture-handler'
import globalStyles from '../../assets/consts/globalStyles'
import { AntDesign } from '@expo/vector-icons';
import ProductsOverwiew from './ProductsOverwiew';

const PaidItems = ({totalPrice, date, productDetails}) => {
   const [isSchowing, setIsSchowing] = useState(false)
   const handleShow = () => {
    setIsSchowing( prevState => !prevState)
   }
  return (
    <ScrollView style={styles.paidProductsContainer} >
        <View style={styles.paidProducts}>
            <Text style={styles.totalPaid}>{Number(totalPrice).toFixed(2)} $</Text>
            <Text style={styles.date}>{date} </Text>
        </View>
        <View>
            <TouchableOpacity 
             onPress={handleShow}
            style={styles.iconBtn}>
            <AntDesign 
                name={isSchowing ? "minuscircleo" :"pluscircleo"} 
                size={24} color={globalStyles.green}/>
            </TouchableOpacity>
            {
                isSchowing && (
                    <View style={styles.detailPaidProduct}>
                        {
                            productDetails.product.map( product => (
                                <ProductsOverwiew 
                                    key={product.id}
                                    name={product.name}
                                    price={product.price}
                                />
                            ))
                        }
                    </View>
                )
            }
        </View>
    </ScrollView>
  )
}


const styles = StyleSheet.create({
    paidProductsContainer:{
        backgroundColor: globalStyles.white,
        borderRadius: 10,
        margin: 20,
        padding: 15
    },
    paidProducts: {
        flexDirection: 'row',
        justifyContent:'space-between',
        alignItems:'center',
        width:'100%',
        marginBottom: 15
    },
    totalPaid:{
        fontSize: 18,
    },
    date:{
        fontSize: 16
    },
    iconBtn:{
        alignSelf: 'flex-end'
    },
    detailPaidProduct: {
        marginTop: 20,
        borderTopColor: globalStyles.lightGrey,
        borderTopWidth: 1
    }
})

export default PaidItems