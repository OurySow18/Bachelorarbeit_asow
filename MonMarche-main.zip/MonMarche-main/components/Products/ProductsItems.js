import React from 'react';
import {
  View,
  TouchableHighlight,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions
} from 'react-native';
import COLORS from '../../assets/consts/colors';
import { AntDesign } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';
import globalStyles from '../../assets/consts/globalStyles';
const width = Dimensions.get('window').width / 2 - 30;

const ProductsItems = (props) => {
  return (
      <View style={{     
        flex: 1,    
        flexDirection: 'row', 
      }}>
    <TouchableHighlight
      activeOpacity={2} 
      underlayColor={COLORS.accentColor}      
      style={{ marginBottom: 30}}
      onPress={props.viewDetails}
    >
        <View style={{
         display: 'flex',                          
         backgroundColor: "white",                        
         justifyContent:"space-between",
         height: 250,
         width: 180,             
         marginTop: 10, 
         marginLeft: 15, 
         padding: 15, 
        }}>
          <Image
            source={{ uri: props.image }}
            style={{
              width: "100%",
              height: 150,
              resizeMode: "contain"
            }} />
            <View style={styles.productContainerDetails}>
             <Text style={styles.productTitel}>{props.name}</Text>
             <Text style={ styles.productTitel}> {props.poids} </Text>
             <Text style={ styles.productPrice}>{props.price} $</Text>
           </View>
          <View style={styles.iconsContainer}>
            <TouchableOpacity
              onPress={props.viewDetails}
            >
              <AntDesign name="eye" size={35} color={COLORS.accentColor} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={props.onAddToCart}
            >
              <Ionicons name="basket" size={35} color={COLORS.accentColor} />
              
            </TouchableOpacity>
          </View>
        </View>
    </TouchableHighlight>
      </View>

  );
};

const styles = StyleSheet.create({
  categoryContainer: {
    marginTop: 30,
    marginBottom: 20,
    justifyContent: 'space-between',
  },
  korb: {
    width: 15,
    height: 15,
    backgroundColor: "red",
    borderRadius: 15,
    color: "white",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 10,
    fontWeight: "bold",
    position: "absolute",
    top: -5,
    right: -5,
  },
  categoryText: { fontSize: 16, color: 'grey', fontWeight: 'bold' },
  categoryTextSelected: {
    color: COLORS.accentColor,
    paddingBottom: 5,
    borderBottomWidth: 2,
    borderColor: COLORS.accentColor,
  },
  card: {
    height: 225,
    backgroundColor: COLORS.light,
    marginHorizontal: 2,
    borderRadius: 10,
    marginBottom: 20,
    padding: 15,
  },
  header: {
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  searchContainer: {
    height: 50,
    backgroundColor: COLORS.light,
    borderRadius: 10,
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  input: {
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
    color: COLORS.dark,
  },
  sortBtn: {
    marginLeft: 10,
    height: 50,
    width: 50,
    borderRadius: 10,
    backgroundColor: COLORS.accentColor,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 'center',
    height: '20%',
    paddingHorizontal: 5
},
productTitel: {
  justifyContent:'space-between',
  alignItems:'center',
  fontSize: 14,
  marginVertical: 2,
  color: COLORS.accentColor,
  fontWeight: 'bold',
  textTransform: 'uppercase',
},
productPrice: {
  color: globalStyles.darkGrey,
  fontSize: 16,
  fontSize: 15, fontWeight: "bold" 
},
productContainerDetails: {
  alignItems: 'center',
  height: '20%',
  padding: 10
},
});
export default ProductsItems;
