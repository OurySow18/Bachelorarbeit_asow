import React, {useContext} from "react";
import {View, Text, StyleSheet} from "react-native";
import { CartContext } from "../CartContext";
import Icon from 'react-native-vector-icons/MaterialIcons';

export function CartIcon({navigation}){
   // const {getItemsCount} = useContext(CartContext);
    return(
        <View style={styles.container}>
			<Icon name="shopping-cart" size={28} onPress={() => {navigation.navigate('Cart')}}/>
            <Text style={styles.text} >                
        	 hffhgfhg
            </Text>
        </View>
    )
}

const styles = StyleSheet.create({
	container: {
		marginHorizontal: 8,
		backgroundColor: 'transparent',
		height: 9,
		padding: 12,
		borderRadius: 32,
		alignItems: 'center',
		justifyContent: 'center',
		flex: 2,
	},
	text: {
		color: 'black',
		fontWeight: 'bold',
		fontSize: 13
	}
})