 const COLORS = { 
  white: '#fff',
  dark: '#000',
  red: '#F52A2A',
  light: '#F1F1F1',
  green: '#00B761',
  primaryColor: '#4a148c',
  accentColor: '#ff6f00',
  backgroundLight: '#F0F0F3',
  backgroundMedium: '#B9B9B9',
  backgroundDark: '#777777'
};

export default COLORS;
