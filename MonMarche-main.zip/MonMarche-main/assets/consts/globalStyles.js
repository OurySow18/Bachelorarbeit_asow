export default{
    green: "#3FA477",
    white: "#fff",
    darkGrey: '#333',
    lightGrey: '#ccc',
    orange: 'orange'
}