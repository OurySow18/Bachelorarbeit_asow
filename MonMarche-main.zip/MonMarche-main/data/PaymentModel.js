
class PaymentModel {
    constructor(id, product, total, date){
        this.id = id;
        this.product = product;
        this.total = total;
        this.date = date;
    }
}

export default PaymentModel