class PaidProduct{
    constructor(id, price, name){
        this.id = id;
        this.price = price;
        this.name = name;
    }
}

export default PaidProduct