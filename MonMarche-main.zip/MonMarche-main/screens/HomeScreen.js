import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Help from './help/Help';
import { CartIcon } from '../components/CartIcon';

import AntDesign from "react-native-vector-icons/AntDesign";
import Octicons from "react-native-vector-icons/Octicons";
import { MaterialIcons } from '@expo/vector-icons';

import NavigationUser from '../navigation/NavigationUser';
import NavigationProducts from '../navigation/NavigationProducts';
import ProductsItems from '../components/products/ProductsItems';

const Tab = createBottomTabNavigator();

function HomeScreen() {

  return (
    <Tab.Navigator
      screenOptions={({ navigation }) => ({
        headerStyle: { backgroundColor: '#ff6f00' },
        headerTintColor: 'white',
        tabBarStyle: { backgroundColor: '#ff6f00' },
        tabBarActiveTintColor: '#fff',
        headerRight: () => <CartIcon navigation={navigation} />
      })}
    >
      <Tab.Screen
        name="Products"
        component={NavigationProducts}
        options={{
          title: 'Monmarche',
          tabBarLabel: 'Acceuil',
          tabBarIcon: ({ color, size }) => (
            <AntDesign name="home" size={24} color="black" />
          )
        }}
      />
      <Tab.Screen
        name="Nos produits"
        component={ProductsItems}
        options={{
          title: 'Nos produits',
          tabBarLabel: 'Nos produits',
          tabBarIcon: ({ color, size }) => (
            <Octicons name="three-bars" size={24} color="black" />
          )
        }}
      />
      <Tab.Screen
        name="User"
        component={NavigationUser}
        options={{
          title: 'Connection',
          tabBarLabel: 'User',
          tabBarIcon: ({ color, size }) => (
            <AntDesign name="user" size={24} color="black" />
          )
        }}
      />
      <Tab.Screen
        name="Aide"
        component={Help}
        options={{
          title: 'La page d´aide',
          tabBarLabel: 'Help',
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="help-outline" size={24} color="black" />
          )
        }}
      />


    </Tab.Navigator>

  );
}

export default HomeScreen;