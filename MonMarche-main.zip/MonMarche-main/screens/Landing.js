/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Die Landing Page ist so zu sagen, wie unser Startseite, weil der User wird dies Seite als erste sehen, 
 * danach kann er navigieren, wie er will.
 * Diese Seite wird unser aktive Produkte zeigen, dazu die verschiedene Kategorien und einer Recherche Komponent
 */
import React, {useEffect, useState}  from 'react'
import { FlatList, View, SafeAreaView } from 'react-native'
import { useDispatch } from 'react-redux' 
import ProductsItems from '../components/products/ProductsItems'
import EmptyMsg from '../components/EmptyMsg'
import {addToCart} from '../redux/actions/actionAddToCart'
import SearchBar from '../components/SearchBar'
import CategoryList from '../components/CategoryList'
import { collection, onSnapshot  } from "firebase/firestore";
import {db} from "../firebase";

function Landing({ navigation }) {

  //ruft unser redux an, wo die actionen implementiert sind
  const dispatch = useDispatch();

  //alle Daten werden hier gespeichert
  const [data, setData] = useState([]);
 
  //addiert das Produkt im Warenkorb
  const handleAddToCart = (product) =>{
    dispatch(addToCart(product));
    alert("Product added to cart");
  }

  //ruft die Produkte von Firebase/Firestore ab und speichert sie in <<data>>
  useEffect(() =>{
    const unsub = onSnapshot(
      collection(db, "products"), 
      (snapShot) => {
      let list = [];
      snapShot.docs.forEach((doc)=>{
        list.push({ id: doc.id, ...doc.data() });
      });
      setData(list);
    }, 
      (error) => {
        console.log(error);
      }
    );
    return () => {
      unsub();
    };
  }, ["products"]);

  //nimmt nur die aktive Produkte und nicht ausverkauft sind 
  const productToDisplay = data.filter( product => product.status === true && product.stock > 0)

  //Wenn wir aktive Produkte haben, dann zeigen wir sie, sonst eine leere Seite mit einer Nachrichst wird angezeigt
  if (productToDisplay.length) {
    return (
      <SafeAreaView>
      <View>
        <SearchBar />
        <CategoryList/>
      <FlatList
        data={productToDisplay}
        numColumns={2}
       
        renderItem={({ item }) => (
          <ProductsItems 
              image={item.img}
              name={item.name}
              price={item.price}
              poids={item.poids}
              viewDetails={() => navigation.navigate("ProductInfos", {
              productId: item.id,
              title: item.name
            })
            }
            onAddToCart={() => handleAddToCart(item)} />
        )} />
        </View>
        </SafeAreaView>
    )
  }
  return <EmptyMsg text="No Products to display" />
}

 
export default Landing