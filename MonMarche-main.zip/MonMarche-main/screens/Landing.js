import React, {useEffect, useState}  from 'react'
import { FlatList, View, SafeAreaView } from 'react-native'
import { useSelector, useDispatch } from 'react-redux' 
import ProductsItems from '../components/products/ProductsItems'
import EmptyMsg from '../components/EmptyMsg'
import {addToCart} from '../redux/actions/actionAddToCart'
import SearchBar from '../components/SearchBar'
import CategoryList from '../components/CategoryList'
import { collection, onSnapshot  } from "firebase/firestore";
import {db} from "../firebase";

function Landing({ navigation }) {

  const dispatch = useDispatch();
  const [data, setData] = useState([]);

  //const existingProducts = useSelector(state => state.products.existingProducts);
  //const productToDisplay = data.filter( product => product.actif === true)  

  const handleAddToCart = (product) =>{
    dispatch(addToCart(product));
    alert("Produit ajouter au panier");
  }

  useEffect(() =>{
    const unsub = onSnapshot(
      collection(db, "products"), 
      (snapShot) => {
      let list = [];
      snapShot.docs.forEach((doc)=>{
        list.push({ id: doc.id, ...doc.data() });
      });
      setData(list);
    }, 
      (error) => {
        console.log(error);
      }
    );
    return () => {
      unsub();
    };
  }, ["products"]);
  const productToDisplay = data.filter( product => product.status === true && product.stock > 0)
  if (productToDisplay.length) {
    return (
      <SafeAreaView>
      <View>
        <SearchBar />
        <CategoryList/>
      <FlatList
        data={productToDisplay}
        numColumns={2}
       
        renderItem={({ item }) => (
          <ProductsItems 
              image={item.img}
              name={item.name}
              price={item.price}
              poids={item.poids}
              viewDetails={() => navigation.navigate("ProductInfos", {
              productId: item.id,
              title: item.name
            })
            }
            onAddToCart={() => handleAddToCart(item)} />
        )} />
        </View>
        </SafeAreaView>
    )
  }
  return <EmptyMsg text="Pas de Produits ä afficher" />
}

 
export default Landing