/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Hilfe Seite, wird später weiter bearbeitet
 */
import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Help = () => {
  return (
    <View>
      <Text>Help</Text>
    </View>
  )
}

export default Help

const styles = StyleSheet.create({})