/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 *  Die Home Komponent ist die Startseite, hier starten wir die Navigationslogik mit der NavigationContainer.
 *  Sie ruft die DrawerNavigator auf, wo die versvhiedene Navigators konfiguriert wird
 */
import React  from 'react'; 
import { NavigationContainer } from '@react-navigation/native'; 
import {DrawerNavigator} from '../navigation/DrawerNav'   
 
 function Home() {
 
    return (
      <NavigationContainer>
        <DrawerNavigator/>
      </NavigationContainer>
    );  
}

export default Home;