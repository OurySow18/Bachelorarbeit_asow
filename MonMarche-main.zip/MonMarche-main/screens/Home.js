import React, {useEffect, useState} from 'react';
import { SafeAreaView, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';

import AppNav from '../navigation/AppNav'; 
import {DrawerNavigator} from '../navigation/DrawerNav' 
//import Onboarding from './onboarding/Onboarding';
import AsyncStorage from '@react-native-async-storage/async-storage';

/*const Loading = () => {
  return (
    <View>
      <ActivityIndicator size="large" />
    </View>
  );
};
*/
 function Home() {
  /* const [loading, setLoading] = useState(true);
    const [viewOnboarding, setViewOnboarding] = useState(false);
  
    const checkOnboarding = async () => {
      try {
        const value = await AsyncStorage.getItem('@viewedOnboarding');
  
        if (value !== null){
          setViewOnboarding(true)
        }
      } catch (error) {
        console.log('Error @checkOnbording: ', error)
      } finally {
        setLoading(false)
      }
    };
  
    useEffect(() => {
      checkOnboarding();
    }, [])
  
    const startSeite = () => {
      return  loading ? <Loading /> : viewOnboarding ? <AppNav /> : <Onboarding />;
    };
  */
    return (
      <NavigationContainer>
        <DrawerNavigator/>
      </NavigationContainer>
    );  
}

export default Home;