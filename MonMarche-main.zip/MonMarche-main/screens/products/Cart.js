import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native'
import React from 'react'
import { useSelector, useDispatch} from 'react-redux'
import EmptyMsg from '../../components/EmptyMsg'
import ProductsInCart from '../../components/products/ProductsInCart'
import globalStyles from '../../assets/consts/globalStyles'
import COLORS from '../../assets/consts/colors'
import { removeProductCart } from '../../redux/actions/actionRemoveProductCart'
import { addPayment } from '../../redux/actions/actionPayement'
import { useNavigation } from '@react-navigation/native'

const Cart = ({navigation}) => {
  const cartProduct = useSelector(state=>state.cart.cartProduct)
  const total = useSelector(state=>state.cart.total)
  const dispatch = useDispatch();
 /* const handlePayment = (cartProduct, total) => {
    dispatch(addPayment(cartProduct, total));
    alert("Payment made")
  }*/ 
  const handlePayment = (cartProduct, total) => {
    navigation.navigate("Delivery", {cartProduct, total});     
  }
  return (
    <View style={styles.container}>
      {
        cartProduct.length > 0 ? (
          <View>
            <FlatList 
              data={cartProduct}
              keyExtractor={ item => item.id}
              renderItem={ ({item}) => (
                <ProductsInCart 
                  name={item.name}
                  price={item.price}
                  onDelete={() => dispatch(removeProductCart(item.id))}
                />
              )}
            />
            <View style={styles.totalContainer}>
                <Text style={styles.totalText} >
                  Total: 
                      <Text style={styles.totalPrice}> {Number(total).toFixed(2)} $</Text>
                </Text> 
                <TouchableOpacity
                  onPress={() => handlePayment(cartProduct, total)}
                >
              <View style={styles.btnAddPayement}>
                <Text style={styles.btnAddPayementText}>Confirm order</Text>
              </View>
            </TouchableOpacity>
            </View>
           
          </View>
        ) 
        :
        (
          <EmptyMsg text="Empty basket"/>
        )
      }
      
    </View>
  )
}

const styles = StyleSheet.create({
  container:{
    margin: 20
  },
  totalContainer:{
    flexDirection: 'row',
    alignItems:'center',
    justifyContent: 'space-between',
    marginTop: 19
  },
  totalText:{
    fontWeight: 'bold',
    fontSize: 19
  },
  totalPrice: {
    color: globalStyles.green
  },
  btnAddPayement:{
    borderRadius: 6,
    paddingVertical: 9,
    paddingHorizontal: 25,
    backgroundColor: COLORS.accentColor
  },
  btnAddPayementText: {
    fontSize: 19
  }
})
export default Cart