import { View, Text, ScrollView, StyleSheet, Image, SafeAreaView, TouchableOpacity } from 'react-native'
import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux';
import COLORS from '../../assets/consts/colors'; 
import {addToCart} from '../../redux/actions/actionAddToCart'
import { doc, onSnapshot  } from "firebase/firestore";
import {db} from "../../firebase";

const ProductInfos = ({ navigation, route }) => {
  const [data, setData] = useState([])
  const [numberProduct, setNumberProduct] = useState(1) 
  const productId = route.params.productId;
  const dispatch = useDispatch(); 

    const handleAddToCart = (product) =>{
      dispatch(addToCart(product));
      alert("Product add to cart");
    }
    const handleMinus = () =>{
      if (numberProduct > 1) {
        setNumberProduct(numberProduct - 1)
      }
    }
    const handlePlus = () =>{
      if (numberProduct < 100) {
        setNumberProduct(numberProduct + 1)
      }
    }

  useEffect(() =>{
    const unsub = onSnapshot(doc(db, "products", productId), (doc) =>  {       
      setData(doc.data());
    }, 
      (error) => {
        console.log(error);
      }
    );
    return () => {
      unsub();
    };
  }, []);

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: '#fff',
      }}>
      <ScrollView>
        <View style={style.imageContainer}>
          <Image source={{ uri: data.img }}
            style={{
              resizeMode: 'contain',
              flex: 1,
              width: 600,
              height: 200,
            }} />
        </View>
        <View style={style.detailsContainer}>
          <View
            style={{
              marginLeft: 20,
              flexDirection: 'row',
              alignItems: 'flex-end',
            }}>
            <View style={style.line} />
            <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Best choice</Text>
          </View>
          <View
            style={{
              marginLeft: 20,
              marginTop: 20,
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
            <Text style={{ fontSize: 22, fontWeight: 'bold' }}>{data.name}</Text>
            <View style={style.priceTag}>
              <Text
                style={{
                  marginLeft: 15,
                  color: '#fff',
                  fontWeight: 'bold',
                  fontSize: 16,
                }}>
                {data.price} $
              </Text>
            </View>
          </View>
          <View style={{ paddingHorizontal: 20, marginTop: 10 }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Description</Text>
            <Text
              style={{
                color: 'grey',
                fontSize: 16,
                lineHeight: 22,
                marginTop: 10,
              }}>
              {data.description}
            </Text>
            <View
              style={{
                marginTop: 20,
                flexDirection: 'row',
                justifyContent: 'space-between',
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                }}>
                <TouchableOpacity onPress={() => handleMinus()}>
                <View style={style.borderBtn}>
                  <Text style={style.borderBtnText}>-</Text>
                </View>
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: 20,
                    marginHorizontal: 10,
                    fontWeight: 'bold',
                  }}>
                  {numberProduct}
                </Text>
             <TouchableOpacity onPress={() => handlePlus()}>
                <View style={style.borderBtn}>
                  <Text style={style.borderBtnText}>+</Text>
                </View>
              </TouchableOpacity>
              </View>
             <TouchableOpacity onPress={() => handleAddToCart(data)}>
              <View style={style.AddToCartBtn}>
                <Text
                  style={{ color: COLORS.white, fontSize: 18, fontWeight: 'bold' }}
                >
                  Add to Cart
                </Text>
              </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>

  );
};

const style = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  imageContainer: {
    flex: 0.45,
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailsContainer: {
    flex: 0.55,
    backgroundColor: COLORS.light,
    marginHorizontal: 7,
    marginBottom: 7,
    borderRadius: 20,
    marginTop: 30,
    paddingTop: 30,
  },
  line: {
    width: 25,
    height: 2,
    backgroundColor: COLORS.dark,
    marginBottom: 5,
    marginRight: 3,
  },
  borderBtn: {
    borderColor: 'grey',
    borderWidth: 1,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    width: 60,
    height: 40,
  },
  borderBtnText: { fontWeight: 'bold', fontSize: 28 },
  AddToCartBtn: {
    width: 130,
    height: 50,
    backgroundColor: COLORS.accentColor,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
  },
  priceTag: {
    backgroundColor: COLORS.accentColor,
    width: 80,
    height: 40,
    justifyContent: 'center',
    borderTopLeftRadius: 25,
    borderBottomLeftRadius: 25,
  },
});
export default ProductInfos