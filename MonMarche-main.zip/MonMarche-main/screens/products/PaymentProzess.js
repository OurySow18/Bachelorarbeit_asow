import {
  StyleSheet,
  Image,
  View,
  ScrollView, 
  Text,
  useWindowDimensions, 
} from "react-native";
import React, { useState, useEffect, useRef } from "react";
import {  useDispatch} from 'react-redux'
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../../firebase";
import Monmarche from "../../assets/images/logo/Monmarche.png"; 
import CustomButton from "../../components/SignIn/CustomButton";
import { ActivityIndicator } from "react-native-paper"; 
import AsyncStorage from "@react-native-async-storage/async-storage"; 
import { RadioButton } from "react-native-paper";
import { addPayment } from '../../redux/actions/actionPayement'
import { FontAwesome, FontAwesome5 } from '@expo/vector-icons';
import COLORS from "../../assets/consts/colors";
import { getAuth } from "firebase/auth";


const PaymentProzess = ({ route, navigation }) => {
  const { deliverInfos,
          cartProduct,
          total} = route.params;
  const [isLoading, setIsLoading] = useState(false);
  const [checked, setChecked] = React.useState("paypal"); 
  const [id, setId] = useState(null);

  const { height } = useWindowDimensions(); 
 
  const dispatch = useDispatch();
  const handlePayment = (cartProduct, total) => {
    dispatch(addPayment(cartProduct, total));
  }

  useEffect(() => {
    load()
  }, []);

  const load = async () => {
    setIsLoading(true);
    const userDetaisStr = await AsyncStorage.getItem("userDetails");
    if (userDetaisStr !== null) {
      const userDetailsObj = JSON.parse(userDetaisStr);
      const { token, useId, dateTokenExpire } = userDetailsObj;
      const expireDate = new Date(dateTokenExpire);
      if (expireDate <= new Date() || !token || !useId) {
        setId(useId);
        setIsLoading(false); 
      }
    } else {
      setId("");
      setIsLoading(false); 
    }
  };

  const handelSubmit = async () => { 
    const auth = getAuth();
    const user = auth.currentUser;

      if  (user) {
        // User is signed in, see docs for a list of available properties
        const uid = user.uid;
        handlePayment();  
          setDoc(doc(db, "orders"), { 
          deliverInfos,
          cartProduct,
          total,
          userId: id,  
          payementMethode: checked,
          timeStamp: serverTimestamp(),
          status: false,
          delivered: false,
        })              
        alert("Payment made")
        navigation.replace('Cart');   
        
        // ...
      } else {
        // User is signed out
        alert("Non connecte")
      }
     
         
     
  };

 
  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.root}>
        {isLoading ? (
          <ActivityIndicator color="white" size={50} />
        ) : (
          <Image
            source={Monmarche}
            style={[styles.logo, { height: height * 0.3 }]}
            resizeMode="contain"
          />
        )}
        <View>
          <Text style={styles.textContainer}>
            <RadioButton
              value="paypal"
              status={checked === "paypal" ? "checked" : "unchecked"}
              onPress={() => setChecked("paypal")}
              color= {COLORS.accentColor}
            />
            <FontAwesome name="cc-paypal" size={100} color="blue" /> PayPal
          </Text>
          <Text style={styles.textContainer}>
            <RadioButton
              value="creditcard"
              status={checked === "creditcard" ? "checked" : "unchecked"}
              onPress={() => setChecked("creditcard")}
              color= {COLORS.accentColor}
            />
            <FontAwesome5 name="credit-card" size={110} color="black" /> Credit Cart
          </Text> 
          <Text style={styles.textContainer}>
            <RadioButton
              value="orangeMoney"
              status={checked === "orangeMoney" ? "checked" : "unchecked"}
              onPress={() => setChecked("orangeMoney")}
              color= {COLORS.accentColor}
            />
           <FontAwesome5 name="money-bill-alt" size={100} color="orange" /> Orange Money
          </Text>
        </View>
        {isLoading ? (
          <ActivityIndicator size={50} color="white" />
        ) : (
          <CustomButton text="Pay" onPress={handelSubmit} />
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  root: {
    alignItems: "center",
    padding: 20,
  },
  logo: {
    width: "70%",
    maxWidth: 300,
    maxHeight: 200,
  },
  textContainer:{
    fontSize: 30,
    alignItems: 'center',
    justifyContent:'center'
  }
});

export default PaymentProzess;
