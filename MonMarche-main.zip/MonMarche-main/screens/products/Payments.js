/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Zeigt alle Bestellungen der User
 */
import { FlatList, StyleSheet } from 'react-native'
import React from 'react'
import { useSelector } from 'react-redux'
import EmptyMsg from '../../components/EmptyMsg';
import PaidItems from '../../components/products/PaidItems';

const Payments = () => {
  //ruft die Daten von der Redux store ab
  const payments = useSelector(state => state.payments.payments);
 if (payments.length > 0){
  return (     
        <FlatList 
          data={payments}
          keyExtractor={item => item.id}
          renderItem={({item}) => (
            <PaidItems 
                totalPrice={item.total}
                date={item.date}
                productDetails={item}
            />
          )}
        />
   )} 
       return <EmptyMsg text="Pas d´achat ä afficher"/>
      
  
}

const styles = StyleSheet.create({})

export default Payments