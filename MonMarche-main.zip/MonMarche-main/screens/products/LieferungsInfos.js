import { StyleSheet, Image, View, ScrollView,TextInput, Text, useWindowDimensions, TouchableOpacity } from 'react-native';
import React, {useState, useEffect, useRef} from 'react';
import {  
  doc, 
  setDoc, 
  serverTimestamp, 
} from "firebase/firestore";
import { auth, db, storage } from "../../firebase";
import Monmarche from '../../assets/images/logo/Monmarche.png';
import CustomInput from '../../components/SignIn/CustomInput';
import CustomButton from '../../components/SignIn/CustomButton';
import { ActivityIndicator } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from "@react-native-async-storage/async-storage"; 

const LieferungsInfos = ({route, navigation}) => {  
  const [recipientName, setRecipientName] = useState('') 
  const [adresse, setAdresse] = useState('')
  const [phone, setPhone] = useState('') 
  const [isLoading, setIsLoading] = useState(false)
  const [data, setData] = useState({});
  const [id, setId] = useState('');
  const [idDoc, setIdDoc] = useState('');
  
  const {height} = useWindowDimensions(); 
  const {cartProduct, total} = route.params;
   
  useEffect( () => {   
    load() 
  }, []);
  
   
  const load = async() =>{
    setIsLoading(true)
    const userDetaisStr = await AsyncStorage.getItem('userDetails');
    if (userDetaisStr !== null){
      const userDetailsObj = JSON.parse(userDetaisStr);
      const {token, userId, dateTokenExpire} = userDetailsObj;
      const expireDate = new Date(dateTokenExpire);        
      if (expireDate <= new Date() || !token || !userId){
        setId(userDetailsObj.useId)  
        setIsLoading(false)
        setIdDoc(id)
      } 
    } else { 
      setId('')
      setIsLoading(false)
      setIdDoc('')
    }  
  }
  
  const handelSubmit = async () => {
    if (recipientName.length > 0 && adresse.length > 0 && phone.length > 0  ){       
       const deliverInfos ={
          recipientName, 
          adresse,
          phone,   
        }
        await AsyncStorage.setItem('userSaved', "true")
        navigation.replace('PaymentProzess', {
          deliverInfos,
          cartProduct,
          total
        } );      
    }else{
      alert('Please complete all fields ')
    }  
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.root}>
        {
          isLoading ? <ActivityIndicator  
            color="white"
            size={50}
          /> :         
          <Image
          source={Monmarche}
          style={[styles.logo, {height: height * 0.3}]}
          resizeMode="contain"
        />
      }
        
        <CustomInput
          placeholder="name of recipient"
          value={recipientName}
          setValue={setRecipientName}
        /> 
        <CustomInput
          placeholder="Addresse, Give the name of the destination district"
          value={adresse}
          setValue={setAdresse}
        />
        <CustomInput
          placeholder="Phone od recipient"
          value={phone}
          setValue={setPhone}
        />    
        { 
            isLoading ? 
            <ActivityIndicator size={50}  color="white"  
            /> 
            :
            <CustomButton text="Valider" onPress={handelSubmit} /> 
        } 
      </View>
    </ScrollView>
  )
}


const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: '70%',
    maxWidth: 300,
    maxHeight: 200,
  },
})

export default LieferungsInfos