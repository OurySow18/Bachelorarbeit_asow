import { StyleSheet, Image, View, ScrollView,TextInput, Text, useWindowDimensions, TouchableOpacity } from 'react-native';
import React, {useState, useLayoutEffect, useRef} from 'react';
import { 
  updateDoc,
  doc, 
  setDoc,
  addDoc,
  collection,
  docSnapshot,
  serverTimestamp,
  onSnapshot
} from "firebase/firestore";
import { auth, db, storage } from "../../firebase";
import Monmarche from '../../assets/images/logo/Monmarche.png';
import CustomInput from '../../components/SignIn/CustomInput';
import CustomButton from '../../components/SignIn/CustomButton';
import { ActivityIndicator, Avatar } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from "@react-native-async-storage/async-storage";
import {useNavigation} from '@react-navigation/core';

const ProfilInfos = () => { 
  const [file, setFile] = useState(""); 
  const [username, setUsername] = useState('')
  const [surname, setSurname] = useState('')
  const [adresse, setAdresse] = useState('')
  const [phone, setPhone] = useState('')
  const [country, setCountry] = useState('')
  const [image, setImage] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [data, setData] = useState({});
  const [id, setId] = useState('');
  const [idDoc, setIdDoc] = useState('');
  
  const {height} = useWindowDimensions(); 
  const navigation = useNavigation(); 
   
  useLayoutEffect(() => {
    load();
  }, []);
   
  const load = async() =>{
    setIsLoading(true)
    const userDetaisStr = await AsyncStorage.getItem("userDetails");
    const userRegistred = await AsyncStorage.getItem("userSaved");
    if (userRegistred !== null){
      if (userRegistred === "true"){ 
        navigation.replace('UserDetails'); 
      }
    }
    
    if (userDetaisStr !== null){
      const userDetailsObj = JSON.parse(userDetaisStr);
      const {token, userId, dateTokenExpire} = userDetailsObj;
      const expireDate = new Date(dateTokenExpire);        
      if (expireDate <= new Date() || !token || !userId){
        setId(userDetailsObj.useId)  
        setIsLoading(false)
        setIdDoc(id)
      } 
    } else { 
      setId('')
      setIsLoading(false)
      setIdDoc('')
    }  
  }
  const handleImage = () => {
    alert("Image Loading ...")     
  }
  const handelSubmit = async () => {
    if (username.length > 0 && surname.length > 0 && adresse.length > 0 && phone.length > 0 && country.length > 0){  
      const userRef = doc(db, 'users', id);
        await setDoc(userRef, { 
          username,
          surname,
          adresse,
          phone,
          country, 
          category: "CLIENT",
          timeStamp: serverTimestamp(),
          status: true,
        })
        await AsyncStorage.setItem('userSaved', "true")
        navigation.replace('UserDetails');      
    }else{
      alert('Please complete all fields ')
    }  
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.root}>
        {
          isLoading ? <ActivityIndicator  
            color="white"
            size={50}
          /> :         
          <Image
          source={Monmarche}
          style={[styles.logo, {height: height * 0.3}]}
          resizeMode="contain"
        />
      }
        <TouchableOpacity onPress={handleImage}>
                <Avatar.Image
                source={{
                  uri: "https://firebasestorage.googleapis.com/v0/b/monmarhe.appspot.com/o/1649763481082Bild_Sow.jpeg?alt=media&token=0adacc52-e4ff-43ed-9c4a-39adfced935f.jpeg",
                }}
                size={90}
              />
              <Text>Image <MaterialIcons name="upload-file" size={24} color="black" /> </Text>              
        </TouchableOpacity>
        <CustomInput
          placeholder="Username"
          value={username}
          setValue={setUsername}
        />
        <CustomInput
          placeholder="Name and surname"
          value={surname}
          setValue={setSurname}
        />
        <CustomInput
          placeholder="Adresse"
          value={adresse}
          setValue={setAdresse}
        />
        <CustomInput
          placeholder="Phone"
          value={phone}
          setValue={setPhone}
        />
        <CustomInput
          placeholder="Country"
          value={country}
          setValue={setCountry}
        />
        

        { 
            isLoading ? 
            <ActivityIndicator size={50}  color="white"  
            /> 
            :
            <CustomButton text="Valider" onPress={handelSubmit} /> 
        } 
      </View>
    </ScrollView>
  )
}


const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: '70%',
    maxWidth: 300,
    maxHeight: 200,
  },
})

export default ProfilInfos