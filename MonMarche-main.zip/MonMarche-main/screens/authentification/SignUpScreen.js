import React, {useState, useEffect} from 'react';
import { useDispatch } from 'react-redux';
import {View, Text, StyleSheet, ScrollView, ActivityIndicator, Alert, Image, useWindowDimensions} from 'react-native';
import CustomInput from '../../components/SignIn/CustomInput';
import CustomButton from '../../components/SignIn/CustomButton';
import SocialSignInButtons from '../../components/SignIn/SocialSignInButtons';
import {useNavigation} from '@react-navigation/core';
import {createUser, actionSignup} from '../../redux/actions/actionAuth'
import Monmarche from '../../assets/images/logo/Monmarche.png';

const SignUpScreen = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordRepeat, setPasswordRepeat] = useState('');
  const [isLoading, setIsLoading] = useState(false);  
  const [error, setError] = useState();
  const dispatch = useDispatch();
  const navigation = useNavigation();  
  const {height} = useWindowDimensions();

  const onRegisterPressed = () => {
    navigation.navigate('ConfirmEmail');
  };

  /*async function signupHandler ({ email, password}){
    try{setIsLoading(true);
    await createUser(email, password);
    alert(email)
    setIsLoading(false);
  }catch(error){
    console.log(error)
  }
  }*/
  useEffect(() => {
    if (error != null){
      Alert.alert(
        'ERREUR',
        error,
        [{text: 'OK'}]
      )
    }
  }, [error])

  const signupHandler = async () => {
    if (email.length > 0 && password.length > 0){
      setError(null)
      try {
        await dispatch(actionSignup(email, password))
            // validate user       
        navigation.navigate('SignIn');
      } catch (error) {
        setError(error.message)
      }
    }else{
      alert('please complete all fields')
    }  
  };

  const onSignInPress = () => {
    navigation.navigate('SignIn');

  };

  const onTermsOfUsePressed = () => {
    console.warn('onTermsOfUsePressed');
  };

  const onPrivacyPressed = () => {
    console.warn('onPrivacyPressed');
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.root}>
      {
          isLoading ? <ActivityIndicator 
          size="large"
          color="white"
        /> :         
        <Image
        source={Monmarche}
        style={[styles.logo, {height: height * 0.3}]}
        resizeMode="contain"
      />
       
      }
 <Text style={styles.title}>Create an account</Text>
   
        <CustomInput placeholder="Email" value={email} setValue={setEmail} />
        <CustomInput
          placeholder="Password"
          value={password}
          setValue={setPassword}
          secureTextEntry
        />       

        <CustomButton text="Register" onPress={signupHandler} />

        <Text style={styles.text}>
          By registering, you confirm that you accept our{' '}
          <Text style={styles.link} onPress={onTermsOfUsePressed}>
            Terms of Use
          </Text>{' '}
          and{' '}
          <Text style={styles.link} onPress={onPrivacyPressed}>
            Privacy Policy
          </Text>
        </Text>

        <SocialSignInButtons />

        <CustomButton
          text="Have an account? Sign in"
          onPress={onSignInPress}
          type="TERTIARY"
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#051C60',
    margin: 10,
  },
  text: {
    color: 'gray',
    marginVertical: 10,
  },
  link: {
    color: '#FDB075',
  },
  logo: {
    width: '70%',
    maxWidth: 300,
    maxHeight: 200,
  },
});

export default SignUpScreen;
