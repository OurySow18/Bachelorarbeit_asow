import React, { useEffect, useLayoutEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  useWindowDimensions,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import Monmarche from "../../assets/images/logo/Monmarche.png";
import CustomInput from "../../components/SignIn/CustomInput";
import CustomButton from "../../components/SignIn/CustomButton";
import SocialSignInButtons from "../../components/SignIn/SocialSignInButtons"; 
import { useNavigation } from "@react-navigation/native";
import { actionLogin } from "../../redux/actions/actionAuth";
import { useDispatch } from "react-redux";
import WaitScreen from "../WaitScreen";
import AsyncStorage from "@react-native-async-storage/async-storage"; 

const SignInScreen = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const [isAuth, setIsAuth] = useState(false);

  const dispatch = useDispatch();
  const { height } = useWindowDimensions();
  const navigation = useNavigation();

  useEffect(() => {
    if (error != null) {
      Alert.alert("ERREUR", error, [{ text: "OK" }]);
    }
  }, [error]);

  useLayoutEffect(() => {
    load();
  }, []);

  const load = async () => {
    const userDetaisStr = await AsyncStorage.getItem("userDetails");     
    
    if (userDetaisStr !== null) {
      const userDetailsObj = JSON.parse(userDetaisStr);
      const { token, userId, dateTokenExpire } = userDetailsObj;
      const expireDate = new Date(dateTokenExpire);
      if (expireDate <= new Date() || !token || !userId) {
        console.log(userDetailsObj.useId);
        setIsAuth(true);
        navigation.replace("ProfilInfos");
        return;
      }
      navigation.replace("ProfilInfos");
      setIsAuth(true);
    } else {
      setIsAuth(true);
    }

    
  };

  const onSignInPressed = async () => {
    if (email.length > 0 && password.length > 0) {
      setError(null);
      try {
        await dispatch(actionLogin(email, password));
        // validate user
        navigation.replace("ProfilInfos");
      } catch (error) {
        setError(error.message);
      }
    } else {
      alert("Please complete all fields ");
    }
  };

  const onSignInPress = () => {
    navigation.navigate("SignIn");
  };

  const onForgotPasswordPressed = () => {
    navigation.navigate("ForgotPassword");
  };

  const onSignUpPress = () => {
    navigation.navigate("SignUp");
  };

  if (isAuth) {
    return (
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.root}>
          {isLoading ? (
            <ActivityIndicator size="large" color="white" />
          ) : (
            <Image
              source={Monmarche}
              style={[styles.logo, { height: height * 0.3 }]}
              resizeMode="contain"
            />
          )}

          <Text style={styles.title}>Login</Text>

          <CustomInput
            placeholder="Email"
            value={email}
            keyboardType="email-address"
            setValue={setEmail}
          />
          <CustomInput
            placeholder="Password"
            value={password}
            setValue={setPassword}
            secureTextEntry
          />

          <CustomButton text="Sign In" onPress={onSignInPressed} />

          <CustomButton
            text="Forgot password?"
            onPress={onForgotPasswordPressed}
            type="TERTIARY"
          />

          <SocialSignInButtons />

          <CustomButton
            text="Don't have an account? Create one"
            onPress={onSignUpPress}
            type="TERTIARY"
          />
        </View>
      </ScrollView>
    );
  }
  return <WaitScreen />;
};

const styles = StyleSheet.create({
  root: {
    alignItems: "center",
    padding: 20,
  },
  logo: {
    width: "70%",
    maxWidth: 300,
    maxHeight: 200,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#051C60",
    margin: 10,
  },
});

export default SignInScreen;
