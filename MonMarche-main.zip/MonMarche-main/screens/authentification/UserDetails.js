import { StyleSheet, Image, View, ScrollView,TextInput, Text, useWindowDimensions, TouchableOpacity } from 'react-native';
import React, {useState, useEffect, useLayoutEffect} from 'react';
import {  
  doc, 
  setDoc, 
  serverTimestamp, 
  onSnapshot,
  getDoc
} from "firebase/firestore";
import { auth, db, storage } from "../../firebase";
import Monmarche from '../../assets/images/logo/Monmarche.png';
import CustomInput from '../../components/SignIn/CustomInput';
import CustomButton from '../../components/SignIn/CustomButton';
import { ActivityIndicator, Avatar } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from "@react-native-async-storage/async-storage";
import {useNavigation} from '@react-navigation/core';

const UserDetails = ( ) => {
      
  const [isLoading, setIsLoading] = useState(false)
  const [data, setData] = useState({}); 
  
  const {height} = useWindowDimensions();  
   
  useEffect(() =>{
    load();     
  }, []);
  
   
  const load = async() =>{
    setIsLoading(true)
    const userDetaisStr = await AsyncStorage.getItem('userDetails');
    if (userDetaisStr !== null){
      const userDetailsObj = JSON.parse(userDetaisStr);
      const {token, userId, dateTokenExpire} = userDetailsObj;
      const expireDate = new Date(dateTokenExpire);        
      if (expireDate <= new Date() || !token || !userId){ 
        setIsLoading(false)
                 
        const docRef = doc(db,"users",userDetailsObj.useId);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          setData(docSnap.data());
        } else {
          // doc.data() will be undefined in this case
          console.log("No such document!");
        }
      } 
    } else { 
      setIsLoading(false)
    }  
  }
  
  const handelEdit = async () => {
    console.log("Edit")
  }; 
  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.root}>
        {
          isLoading ? <ActivityIndicator  
            color="white"
            size={50}
          /> :         
          <Image
          source={Monmarche}
          style={[styles.logo, {height: height * 0.3}]}
          resizeMode="contain"
        />
      }
        <Avatar.Image
                source={{
                  uri: "https://firebasestorage.googleapis.com/v0/b/monmarhe.appspot.com/o/1649763481082Bild_Sow.jpeg?alt=media&token=0adacc52-e4ff-43ed-9c4a-39adfced935f.jpeg",
                }}
                size={90}
              />
        <View>
          <Text>Username</Text> 
          <Text>{data.username}</Text> 
         </View>
        <View>
          <Text>Name and Surname</Text> 
          <Text>{data.surname}</Text> 
         </View>
        <View>
          <Text>Addresse</Text> 
          <Text>{data.adresse}</Text> 
         </View>
        <View>
          <Text>Country</Text> 
          <Text>{data.country}</Text> 
         </View>
        { 
            isLoading ? 
            <ActivityIndicator size={50}  color="white"  
            /> 
            :
            <CustomButton text="Edit" onPress={handelEdit} /> 
        } 
      </View>
    </ScrollView>
  )
}


const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: '70%',
    maxWidth: 300,
    maxHeight: 200,
  },
})

export default UserDetails