/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Reducer, um die Produkte zu verwalten
 */
import PaidProduct from '../../data/PaidProductModel'
import { ADD_TO_CART, REMOVE_PRODUCT_CART, ADD_PAYMENT } from '../constants'

const initialState = {
    cartProduct: [],  //idProduct, price, name
    total: 0
}
const reducerCart = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TO_CART:
      
      const product = action.product;
      const idProduct = product.id;
      const name = product.name;
      const price = product.price;
  
      const newProduct = new PaidProduct(idProduct, price, name);

      return {
        ...state,
        cartProduct: state.cartProduct.concat(newProduct),
        total: Number(state.total) + Number(price)
      }

      case REMOVE_PRODUCT_CART:
        const indexResult = state.cartProduct.findIndex( product => product.id === action.prodId);
        const newCartProductsArray = [...state.cartProduct];
        newCartProductsArray.splice(indexResult, 1);

        const productPrice = state.cartProduct[indexResult].price;

        return {
          ...state,
          cartProduct: newCartProductsArray,
          total: Number(state.total) - Number(productPrice)
        }
      case ADD_PAYMENT:
        return initialState
    default:
      return state;
  }
}
 
export default reducerCart