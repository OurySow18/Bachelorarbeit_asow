import PRODUCTS from '../../data/testData';
import { ADD_TO_CART, REMOVE_PRODUCT_CART } from '../constants';

const initialState = {
    existingProducts: PRODUCTS
} 
 

const reducerProducts = (state = initialState, action) => {  
 const prod = Object.values(state.existingProducts) 
   console.log(prod.name)
    switch (action.type) {
        case ADD_TO_CART:
            const indexProductToModify =  prod.findIndex(product => product.id === action.product.id);

            const copyExistingProducts = [...prod];
            copyExistingProducts[indexProductToModify].status = false;
            return{
                ...state,
                existingProducts: copyExistingProducts
            }

        case REMOVE_PRODUCT_CART:
            const indexProductToDeleteFromCart = state.existingProducts.findIndex(product => product.id === action.prodId);
            const copyExistingProductsRemoved = [...state.existingProducts];
            copyExistingProductsRemoved[indexProductToDeleteFromCart].actif = true;

            return{
                ...state,
                existingProducts: copyExistingProductsRemoved
            }
        default:
            return state;
    }
}

export default reducerProducts;