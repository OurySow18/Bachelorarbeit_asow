import {createStore, combineReducers, applyMiddleware} from 'redux';
import reducerCart from './reducers/reducerCart';
import reducerProducts from './reducers/reducersProducts';
import reducerPayment from './reducers/reducerPayment'
import reducerUsers from './reducers/reducerUsers';
import thunk from 'redux-thunk';

const rootReducers = combineReducers({
    cart: reducerCart,
    payments: reducerPayment,
    users: reducerUsers
})


const store = createStore(rootReducers, applyMiddleware(thunk));

export default store;