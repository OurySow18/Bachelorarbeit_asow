/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Definiert die notwendige Konstanten für die Aktionen
 */
export const ADD_TO_CART = "ADD_TO_CART";
export const REMOVE_PRODUCT_CART = "REMOVE_PRODUCT_CART";
export const ADD_PAYMENT = "ADD_PAYMENT";
export const AUTH_USER = "AUTH_USER";
