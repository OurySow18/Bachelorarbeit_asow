/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Reducer für die Löschung von Produkte aus dem Warenkorb
 */
import { REMOVE_PRODUCT_CART } from '../constants'

export const removeProductCart = (productId) => {
  return{
    type: REMOVE_PRODUCT_CART,
    prodId: productId
  }
}

