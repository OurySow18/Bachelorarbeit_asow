import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { REMOVE_PRODUCT_CART } from '../constants'

export const removeProductCart = (productId) => {
  return{
    type: REMOVE_PRODUCT_CART,
    prodId: productId
  }
}

