/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Reducer Payement
 */
import { ADD_PAYMENT } from "../constants";

export const addPayment = (cartProduct, total) => {
    return {
        type: ADD_PAYMENT,
        orderInfos: {
            product: cartProduct,
            total: total
        }
    }
}