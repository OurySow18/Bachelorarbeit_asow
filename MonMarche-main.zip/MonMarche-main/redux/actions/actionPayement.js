import { ADD_PAYMENT } from "../constants";

export const addPayment = (cartProduct, total) => {
    return {
        type: ADD_PAYMENT,
        orderInfos: {
            product: cartProduct,
            total: total
        }
    }
}