/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Aktion addToCart
 */
import { ADD_TO_CART } from "../constants";

export const addToCart = (product) => {
    return {
        type: ADD_TO_CART,
        product: product
    }
}