/**
 * Abgabe Bachelorarbeit
 * Author: Amadou Oury Sow
 * Date: 15.09.2022
 * 
 * Authentikation reducer
 */
import { AUTH_USER } from "../constants";
import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";

const API_KEY = "AIzaSyDCENsh0tZlNtbcNAZZHqt1RtkNIsWsNuE";

export async function createUser(email, password) {
  try {
    const response = await axios.post(
      "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" +
        API_KEY,
      {
        email: email,
        password: password,
        returnSecureToken: true,
      }
    );
  } catch (error) {
    console.log(error);
  }
}
// Registration
export const actionSignup = (email, password) => {
  return async (dispatch) => {
    //http request
    const response = await fetch(
      "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyDCENsh0tZlNtbcNAZZHqt1RtkNIsWsNuE",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
          returnSecureToken: true,
        }),
      }
    );

    //response
    if (!response.ok) {
      //message d´erreur
      const responseError = await response.json();
      const errorMsg = responseError.error.message;

      let customMsg = "Oops, we have a problem during registration";

      if (errorMsg === "EMAIL_EXISTS") {
        customMsg = "This Emai exists, log in";
      } else if (errorMsg === "TOO_MANY_ATTEMPTS_TRY_LATER") {
        customMsg = "Too many attempts, please try again later";
      }
      throw new Error(customMsg);
    }

    const dataObj = await response.json();
    //dispatch action
    dispatch(actionAuthUser(dataObj.localId, dataObj.idToken));

    //AsyncStorage
    const expiresInMilisec = parseInt(dataObj.expiresIn) * 1000;
    const expireDate = new Date().getTime() + expiresInMilisec;
    const dateTokenExpire = new Date(expireDate).toISOString();

    saveToAsyncStorage(dataObj.idToken, dataObj.localId, dateTokenExpire);
    saveUserToAsyncStorage(false);
  };
};

// Connexion
export const actionLogin = (email, password) => {
  return async (dispatch) => {
    //http request
    const response = await fetch(
      "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyDCENsh0tZlNtbcNAZZHqt1RtkNIsWsNuE",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
          returnSecureToken: true,
        }),
      }
    );
   
    //response
    if (!response.ok) {
      //message d´erreur
      const responseError = await response.json();
      const errorMsg = responseError.error.message;

      let customMsg = "Oops, we have a problem during Login";

      if (errorMsg === "EMAIL_NOT_FOUND") {
        customMsg =
          "This Emai doesnt exists, do you want to create a user with this Email? ";
      } else if (errorMsg === "INVALID_PASSWORD") {
        customMsg = "Invalid password, please try again";
      }
      throw new Error(customMsg);
    }

    const dataObj = await response.json();
    //dispatch action
    dispatch(actionAuthUser(dataObj.localId, dataObj.idToken));

    //AsyncStorage
    const expiresInMilisec = parseInt(dataObj.expiresIn) * 1000;
    const expireDate = new Date().getTime() + expiresInMilisec;
    const dateTokenExpire = new Date(expireDate).toISOString();

    saveToAsyncStorage(dataObj.idToken, dataObj.localId, dateTokenExpire);
  };
};

//Enregistrer la data dans AsyncStorage
const saveToAsyncStorage = async (token, useId, dateTokenExpire) => {
  await AsyncStorage.setItem(
    "userDetails",
    JSON.stringify({
      token,
      useId,
      dateTokenExpire, 
    })
  );
};
const saveUserToAsyncStorage = async (isSaved) => {   
    await AsyncStorage.setItem(
    "userSaved",
    JSON.stringify({
     isSaved
    })
  );  
};
//Auth action
const actionAuthUser = (userId, token) => {
  return {
    type: AUTH_USER,
    userId: userId,
    token: token,
  };
};
